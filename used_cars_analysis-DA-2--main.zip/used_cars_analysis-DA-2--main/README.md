used_cars.xlsx --> Processed Excel file

used_cars.csv  --> Raw data (USE WITH .IPYNB FILE)
